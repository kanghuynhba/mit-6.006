def solve_special(C):
    """
    Given a set of linear equations C, returns a solving assignment to variables
    if the set of equations is delegated and special, and None otherwise
    Input: 
        C is a list of n lists, each with length n + 1
        C_i = [d_i, c_i1, c_i2, ... c_in]
        C_i represents equation:  0 = d_i + \sum_j c_ij * x_j
    Output: 
        x = [x_1, ... x_n] 
        solving assignment of variables
    """
    x = None
    return x

##################
# Test your code #
##################
def test_on_case(case):
    with open('cases/' + str(case) + '.in', 'r') as f:
        s = f.read()
        C = s.split('\n')
        n = len(C)
        for i in range(n):
            C[i] = C[i].split(' ')
            for j in range(n + 1):
                C[i][j] = int(C[i][j])
        x = solve_special(C)
    with open('cases/' + str(case) + '.out', 'r') as f:
        golden = f.read()
        if golden == 'None':
            golden = None 
        else:
            golden = [int(i) for i in golden.split(' ')]
        print(golden)
        print(x)
        if x == golden:
            print('Passed test case ' + str(case) + '!')
        else:
            print('Failed test case ' + str(case) + '... :(')

if __name__ == '__main__':
    for case in [1, 2]:
        test_on_case(case)
