def count_anagrams(strings):
    "Return the number of pairs of anagrams in a tuple of strings"
    ##################
    # YOUR CODE HERE #
    ##################
    return 0
