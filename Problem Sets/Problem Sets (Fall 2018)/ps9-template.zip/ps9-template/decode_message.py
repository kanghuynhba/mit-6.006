def decode_message(A):
    """
    Return the first half of the longest palindrome subsequence of string A
    """
    return ''
