def proximate_sort(A, k):
    ''' 
    Return an array containing the elements of 
    input tuple A appearing in sorted order.
    Input:  k | an integer < len(A)
            A | a k-proximate tuple
    '''
    ##################
    # YOUR CODE HERE #
    ##################
    return []
